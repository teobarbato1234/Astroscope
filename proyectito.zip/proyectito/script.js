// Espera a que el documento HTML esté cargado antes de buscar elementos
// y conectar los eventos del formulario.
document.addEventListener("DOMContentLoaded", () => {

    // Elemento donde se muestran errores o mensajes de éxito al usuario.
    const feedback = document.getElementById("feedback");

    // Actualiza el mensaje visible y vuelve a localizarlo si hay soporte
    // de traducciones cargado en la página.
    function showFeedback(message) {
        // Algunas páginas pueden no tener un elemento de mensajes.
        if (!feedback) return;

        // Evita que el sistema de traducción reemplace el mensaje dinámico.
        feedback.removeAttribute("data-i18n-block");
        feedback.textContent = message;

        // La función de traducción no está presente en todas las páginas.
        if (typeof localizeFeedback === "function") localizeFeedback();
    }

    // Lee los parámetros de la URL, por ejemplo ?error=... o ?success=...
    const params = new URLSearchParams(window.location.search);

    // Si la URL incluye un error, lo muestra con el estilo correspondiente.
    if (params.has("error")) {
        showFeedback(params.get("error"));
        feedback.className = "error";
    // Si no hay error pero sí éxito, muestra el mensaje de confirmación.
    } else if (params.has("success")) {
        showFeedback(params.get("success"));
        feedback.className = "success";
    }

    // Busca el formulario de registro; en otras páginas puede no existir.
    const registerForm = document.getElementById('registerForm');

    // Solo se configura la validación si se encontró el formulario.
    if (registerForm) {
        // Valida los campos antes de que el navegador envíe el formulario.
        registerForm.addEventListener('submit', function(event) {
            // Obtiene los valores escritos en los campos de usuario y contraseña.
            const user = document.getElementById('username').value;
            const pass = document.getElementById('password').value;

            // El nombre de usuario debe incluir al menos una letra y un número.
            const hasLetter = /[a-zA-Z]/.test(user);
            const hasNumber = /[0-9]/.test(user);

            // Detiene el envío y muestra el motivo si falta alguno de ellos.
            if (!hasLetter || !hasNumber) {
                event.preventDefault();
                showFeedback("Username must contain at least one letter and one number.");
                feedback.className = "error";
                return;
            }

            // Comprueba los tipos de caracteres requeridos para la contraseña:
            // una minúscula, una mayúscula, un dígito y un carácter especial.
            const hasLowercase = /[a-z]/.test(pass);
            const hasUppercase = /[A-Z]/.test(pass);
            const hasDigit = /[0-9]/.test(pass);
            const hasSpecialChar = /[!@#\$%\^&\*\(\)_\+\-=\[\]{};':"\\|,.<>\/?]/.test(pass);

            // Guarda las longitudes para aplicar los límites del registro.
            const userLength = user.length;
            const passLength = pass.length;

            // El nombre de usuario debe tener como mínimo 5 caracteres.
            const isUserTooShort = userLength < 5;

            if (isUserTooShort) {
                event.preventDefault();
                showFeedback("Username must be at least 5 characters.");
                feedback.className = "error";
                return;
            }

            // La contraseña debe tener como mínimo 8 caracteres.
            const minimo = passLength < 8;

            if (minimo) {
                event.preventDefault();
                showFeedback("Password must be at least 8 characters.");
                feedback.className = "error";
                return;
            }

            // La contraseña no puede superar los 15 caracteres.
            const maximo = passLength > 15;

            if (maximo) {
                event.preventDefault();
                showFeedback("Password must be no more than 15 characters.");
                feedback.className = "error";
                return;
            }

            // El nombre de usuario tampoco puede superar los 15 caracteres.
            const maximoUser = userLength > 15;

            if (maximoUser) {
                event.preventDefault();
                showFeedback("Username must be no more than 15 characters.");
                feedback.className = "error";
                return;
            }

            // Si falta alguno de los tipos de caracteres requeridos,
            // cancela el envío y explica las condiciones de la contraseña.
            if (!hasLowercase || !hasUppercase || !hasDigit || !hasSpecialChar) {
                event.preventDefault();
                showFeedback("Password must contain a lowercase, uppercase, number, and special character.");
                feedback.className = "error";
                return;
            }

            // Si todas las validaciones pasan, el formulario continúa
            // con su envío normal al servidor.
        });
    }
});