-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 23-10-2026 a las 14:15:43
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `registration`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(16, 'teoba12434!!', '$2y$10$u5.urNjoVVvYwfpJn7l0e.7wZ35DiRawhA.Kw0LPj7AzNv4B6w34u'),
(17, 'teoba123', '$2y$10$sSAUbLgMWeEzhgEjBHiNHe85YevzU448ho1craGBjYZp46dQgh33.'),
(19, 'Prueba1', '$2y$10$eggbsxQUri7BKcB0o1AVZ.AhzA2hc009J9mP9lIXuSzK9NKqR48d6'),
(20, 'teoba12&lt;_Q', '$2y$10$0nxmqr59SH1Uzq9TK6Q0WuetWePlFTaYhx7JBOVqLMJuKoSNr1SzW'),
(21, 'gfgfg-G555', '$2y$10$DbP3yFaUvzMXrVIOnjwQCOSD0M/wXXeFjKHMb9/vk7lEOFDdtkPR6'),
(24, 'teardoXD_223', '$2y$10$d5Fdn/i7v94S4UyFPTjMiethOqrvdMIUoLO7W/TJeIXCPzKxndlR6'),
(25, 'Prueba_2', '$2y$10$c5iB9QCZoaiO5MowMrGd5.rs.KEaMLj78SU7LJg.ByCNeojGTbJYW');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
