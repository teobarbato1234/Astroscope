// One JSON file for all pages.
let currentLang = "en";
let translations = {};
try {
    const saved = localStorage.getItem("preferredLang");
    if (saved === "es" || saved === "en") currentLang = saved;
} catch (error) {
    // Language switching still works if the browser does not allow saving the preference.
}

fetch("translations.json?v=20261023")
    .then(response => {
        if (!response.ok) throw new Error("No se pudo cargar translations.json");
        return response.json();
    })
    .then(data => {
        translations = data;
        applyLanguage();
    })
    .catch(error => {
        console.error(error);
        const btn = document.getElementById("lang-btn");
        if (btn) {
            btn.textContent = "Idioma no disponible / Language unavailable";
            btn.disabled = true;
        }
    });

// Also translate form messages and messages sent by PHP.
function localizeFeedback() {
    const feedback = document.getElementById("feedback");
    if (!feedback || !translations[currentLang]) return;
    let key = feedback.getAttribute("data-i18n-block");
    if (!key) {
        const text = feedback.textContent.trim();
        const previousMessages = {
            "Registration failed. Username may exist.": "mensaje_registro_error",
            "Please log in first": "mensaje_entrar"
        };
        key = previousMessages[text];
        for (const language of ["en", "es"]) {
            for (const name of Object.keys(translations[language])) {
                if (name.startsWith("mensaje_") && translations[language][name] === text) key = name;
            }
        }
    }
    if (key && translations[currentLang][key]) {
        feedback.setAttribute("data-i18n-block", key);
        feedback.textContent = translations[currentLang][key];
    }
}

function applyLanguage() {
    const dictionary = translations[currentLang];
    if (!dictionary) return;
    document.documentElement.lang = currentLang;
    document.querySelectorAll("[data-i18n-block]").forEach(block => {
        const key = block.getAttribute("data-i18n-block");
        if (Object.prototype.hasOwnProperty.call(dictionary, key)) {
            // The HTML comes only from our local JSON file.
            block.innerHTML = dictionary[key];
        }
    });
    // Each link's text comes after the line break.
    document.querySelectorAll("[data-i18n-nav]").forEach(link => {
        const key = link.getAttribute("data-i18n-nav");
        if (Object.prototype.hasOwnProperty.call(dictionary, key)) {
            link.lastChild.textContent = dictionary[key];
        }
    });
    // Change only the initial text, preserving the logo or username.
    document.querySelectorAll("[data-i18n-text]").forEach(element => {
        const key = element.getAttribute("data-i18n-text");
        if (Object.prototype.hasOwnProperty.call(dictionary, key)) {
            // Find the heading text without selecting comments or images.
            for (const node of element.childNodes) {
                if (node.nodeType === 3 && node.textContent.trim() !== "") {
                    node.textContent = dictionary[key] + " ";
                    break;
                }
            }
        }
    });
    const btn = document.getElementById("lang-btn");
    if (btn) btn.textContent = dictionary.idioma;
    localizeFeedback();
}

function toggleLanguage() {
    if (!translations.en || !translations.es) return;
    currentLang = currentLang === "en" ? "es" : "en";
    try { localStorage.setItem("preferredLang", currentLang); } catch (error) {}
    applyLanguage();
}
