// Check again when returning with the browser's back button.
window.addEventListener("pageshow", actualizarSesion);

async function actualizarSesion() {
    const boton = document.querySelector('[data-i18n-nav="login"], [data-i18n-nav="salir"]');
    if (!boton) return;

    try {
        const respuesta = await fetch("sesion.php", {
            cache: "no-store",
            credentials: "same-origin"
        });
        if (!respuesta.ok) throw new Error("No se pudo consultar la sesión");
        const sesion = await respuesta.json();
        if (typeof sesion.conectado !== "boolean") return;

        if (sesion.conectado) {
            boton.href = "logout.php";
            boton.setAttribute("data-i18n-nav", "salir");
            boton.innerHTML = "→<br>Log out";
        } else {
            boton.href = "login.html";
            boton.setAttribute("data-i18n-nav", "login");
            boton.innerHTML = "→<br>Log in";
        }

        // Use the selected language after changing the translation key.
        if (typeof applyLanguage === "function") applyLanguage();
    } catch (error) {
        console.error("No se pudo comprobar la sesión:", error);
    }
}
