<?php
session_start();

// If user is not logged in, redirect to login
if (!isset($_SESSION['username'])) {
    header("Location: login.html?error=Please log in first");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title data-i18n-block="pestana_bienvenida">Welcome</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="idioma"><button id="lang-btn" type="button" onclick="toggleLanguage()">Switch to Español</button></div>

    <div class="welcome" data-i18n-text="saludo">Welcome, <div style="display: inline;"><?php echo htmlspecialchars($_SESSION['username']); ?>!</div> 
    </div>

    <div class="logout">
        <a href="logout.php" data-i18n-block="salir">Logout</a>
    </div>
<script src="translations.js?v=20261023"></script>
</body>
</html>