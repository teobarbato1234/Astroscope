<?php
// Return only whether the visitor is logged in.
session_start();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
echo json_encode(['conectado' => isset($_SESSION['username'])]);
