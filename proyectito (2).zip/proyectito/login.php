<?php
session_start();
require_once 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $input_user = trim($_POST['username'] ?? '');
    $input_pass = $_POST['password'] ?? '';

    $stmt = $conn->prepare("SELECT username, password FROM users WHERE username = ?");
    $stmt->bind_param("s", $input_user);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();

        if (password_verify($input_pass, $user['password'])) {
            session_regenerate_id(true);
            $_SESSION['username'] = $user['username'];
            header("Location: teo_y_paula_parcial.html"); // página a la que va después de iniciar sesión
            exit();
        }
    }

    header("Location: login.html?error=" . urlencode("Usuario o contraseña incorrectos."));
    exit();
}

header("Location: login.html");
exit();
?>