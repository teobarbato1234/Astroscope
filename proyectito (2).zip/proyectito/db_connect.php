<?php

$servername = "localhost";
$username = "Teo_Barbato"; // default username in xampp
$password = "@teardoXD_2009"; // default password in xampp
$dbname = "registration"; // Name of database in SQL

// connecting with value from variables
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>